/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Alghoritms;

import java.awt.Color;
import java.awt.Graphics2D;

/**
 *
 * @author gerson.lucas_unesp
 */
public class RotacionEllipse {
    int x,y;
    
    
    public RotacionEllipse(int x, int y){
        this.x = x;
        this.y = y;
    }
    
    public void drawRotacionEllipse(int x, int y, int x1, int y1, Graphics2D g2d, Color color){
        
    }
    
}
